function paginate(arr,page,limit){
  return arr.slice((page-1)*limit,page*limit);
}

console.assert(paginate([1,2,3,4,5],2,2)[0]===3,'Pagination failed');
console.log('All tests passed');
