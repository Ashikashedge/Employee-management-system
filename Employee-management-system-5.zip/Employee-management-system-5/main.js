import { fetchUsers } from './services/api.js';
import { renderTable } from './components/Table.js';
import { renderPagination } from './components/Pagination.js';

let currentPage = 1;
const limit = 5;

window.loadPage = function(page){
  currentPage = page;
  fetchUsers(page, limit).then(data => {
    renderTable(data);
    renderPagination(currentPage);
  });
}

loadPage(1);
