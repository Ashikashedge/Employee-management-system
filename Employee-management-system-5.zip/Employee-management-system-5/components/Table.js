export function renderTable(users){
  const table = document.getElementById('userTable');
  table.innerHTML = '';
  users.forEach(u => {
    table.innerHTML += `<tr>
      <td>${u.id}</td>
      <td>${u.name}</td>
      <td>${u.email}</td>
      <td>
        <button class="btn btn-warning btn-sm">Edit</button>
        <button class="btn btn-danger btn-sm">Delete</button>
      </td>
    </tr>`;
  });
}
