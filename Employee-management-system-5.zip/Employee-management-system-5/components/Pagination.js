export function renderPagination(active){
  const pag = document.getElementById('pagination');
  pag.innerHTML = '';
  for(let i=1;i<=5;i++){
    pag.innerHTML += `<li class="page-item ${i===active?'active':''}">
      <button class="page-link" onclick="loadPage(${i})">${i}</button>
    </li>`;
  }
}
