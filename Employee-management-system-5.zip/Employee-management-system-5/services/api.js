export function fetchUsers(page, limit){
  return fetch(`https://jsonplaceholder.typicode.com/users?_page=${page}&_limit=${limit}`)
    .then(res => res.json());
}
